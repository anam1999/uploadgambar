<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hadiah extends Model
{
    protected $table = "hadiahs";
           protected $fillable=[
'hadiah','poin_id'
      ];

       public function poin(){
    	
    	return $this->belongsTo('App\Poin','poin_id','id');
    }
}
